export default function IanzonStoreLanding() {
  return (
    <div className="bg-white text-gray-900 p-6 space-y-12">
      {/* Encabezado */}
      <header className="text-center space-y-2">
        <h1 className="text-4xl font-bold">¡Gracias por tu compra!</h1>
        <p className="text-lg text-gray-600">Bienvenido a Ianzon Store</p>
      </header>

      {/* Instrucciones de uso */}
      <section className="space-y-6">
        <h2 className="text-2xl font-semibold">¿Cómo usar tu Card Binder?</h2>
        <ol className="list-decimal list-inside text-gray-700 space-y-2">
          <li>Abre el binder y acomoda tus páginas. Asegúrate de que las anillas estén bien alineadas.</li>
          <li>Inserta tus cartas en cada bolsillo comenzando desde la esquina inferior derecha para evitar dobleces.</li>
          <li>Utiliza los Toploaders incluidos para proteger tus cartas más valiosas y colócalos en los bolsillos grandes si tu modelo los incluye.</li>
          <li>Guarda el binder en un lugar seco y seguro, alejado de la luz directa del sol y fuentes de humedad.</li>
        </ol>
        <div className="mt-4">
          <h3 className="text-xl font-semibold">Video tutorial:</h3>
          <div className="aspect-w-16 aspect-h-9">
            <iframe
              className="w-full h-64 rounded-xl shadow"
              src="https://www.youtube.com/embed/dQw4w9WgXcQ"
              title="Cómo usar tu Card Binder"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
          </div>
        </div>
      </section>

      {/* Tips */}
      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">Consejos para coleccionistas</h2>
        <ul className="list-disc list-inside text-gray-700 space-y-2">
          <li>Organiza tus cartas por tipo, equipo o rareza. Esto facilitará encontrarlas y mantener el orden.</li>
          <li>No expongas tus cartas directamente al sol. La luz UV puede decolorarlas con el tiempo.</li>
          <li>Evita la humedad: usa desecantes si guardas tu colección en clósets o bodegas.</li>
          <li>Revisa tu colección regularmente para detectar posibles daños y reorganizar si es necesario.</li>
          <li>Etiqueta tus páginas con divisores si coleccionas por sets o años.</li>
        </ul>
      </section>

      {/* Testimonios de clientes */}
      <section className="space-y-6">
        <h2 className="text-2xl font-semibold text-center">Lo que dicen nuestros clientes</h2>
        <div className="grid gap-4 md:grid-cols-3">
          <blockquote className="bg-gray-100 p-4 rounded-xl shadow">
            <p className="italic">"Me encantó la calidad del binder. Mis cartas están súper protegidas."</p>
            <footer className="mt-2 text-sm text-right">– Alex R.</footer>
          </blockquote>
          <blockquote className="bg-gray-100 p-4 rounded-xl shadow">
            <p className="italic">"El diseño está increíble, y el QR con instrucciones fue un plus genial."</p>
            <footer className="mt-2 text-sm text-right">– Mariana G.</footer>
          </blockquote>
          <blockquote className="bg-gray-100 p-4 rounded-xl shadow">
            <p className="italic">"Compré dos y seguro regresaré por más. Muy recomendado."</p>
            <footer className="mt-2 text-sm text-right">– Diego L.</footer>
          </blockquote>
        </div>
      </section>

      {/* Galería de fotos */}
      <section className="space-y-6">
        <h2 className="text-2xl font-semibold text-center">Galería de nuestros clientes</h2>
        <div className="grid gap-4 md:grid-cols-3">
          <img src="https://via.placeholder.com/300x200" alt="Cliente usando el binder 1" className="rounded-xl shadow" />
          <img src="https://via.placeholder.com/300x200" alt="Cliente usando el binder 2" className="rounded-xl shadow" />
          <img src="https://via.placeholder.com/300x200" alt="Cliente usando el binder 3" className="rounded-xl shadow" />
        </div>
      </section>

      {/* Preguntas Frecuentes */}
      <section className="space-y-6">
        <h2 className="text-2xl font-semibold text-center">Preguntas Frecuentes</h2>
        <div className="space-y-4 text-gray-700">
          <div>
            <h3 className="font-semibold">¿Cuántas cartas caben en el Card Binder?</h3>
            <p>El binder tiene capacidad para 990 cartas si se utilizan ambos lados de cada hoja.</p>
          </div>
          <div>
            <h3 className="font-semibold">¿Qué tamaño de cartas puedo guardar?</h3>
            <p>Está diseñado para cartas estándar tipo Pokémon, Magic, Yu-Gi-Oh y deportivas como béisbol.</p>
          </div>
          <div>
            <h3 className="font-semibold">¿Viene con Toploaders?</h3>
            <p>Sí, cada binder incluye 25 Toploaders de 35pt para que protejas tus cartas más valiosas.</p>
          </div>
          <div>
            <h3 className="font-semibold">¿Puedo pedir más de uno?</h3>
            <p>¡Claro! Visita nuestra tienda en Amazon para ver paquetes múltiples o promociones.</p>
          </div>
        </div>
      </section>

      {/* Catálogo / Amazon */}
      <section className="text-center space-y-4">
        <h2 className="text-2xl font-semibold">¿Quieres más productos?</h2>
        <p className="text-gray-600">Explora nuestra tienda para más accesorios de colección y novedades.</p>
        <a
          href="https://www.amazon.com/"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-blue-600 text-white px-6 py-2 rounded-xl shadow hover:bg-blue-700"
        >
          Ir a Amazon
        </a>
      </section>

      {/* Contacto / redes */}
      <footer className="text-center space-y-4 text-sm text-gray-500">
        <p>Síguenos en Instagram: @IanzonStore</p>
        <p>Síguenos en TikTok: <a href="https://www.tiktok.com/@ianzonstore" target="_blank" className="text-blue-600 hover:underline">@ianzonstore</a></p>
        <div className="mt-4">
          <h3 className="text-base font-semibold mb-2">Último video en TikTok</h3>
          <div className="flex justify-center">
            <iframe 
              src="https://www.tiktok.com/embed/v2/1234567890123456789" 
              width="325" 
              height="575" 
              allowFullScreen 
              className="rounded-xl shadow"
              title="TikTok video">
            </iframe>
          </div>
        </div>
        <p className="mt-4">¿Tienes dudas? Escríbenos a contacto@ianzonstore.com</p>
      </footer>
    </div>
  );
}